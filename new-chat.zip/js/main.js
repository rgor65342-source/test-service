/* ЕвроШинСервис — общий скрипт (без фреймворков) */
(function () {
  'use strict';

  /* ===== НАСТРОЙКИ — заменить перед запуском ===== */
  var CONFIG = {
    YANDEX_API_KEY: '',                      // ключ API Яндекс.Карт; пока пусто — показывается заглушка
    CITY_CENTER: [55.751244, 37.618423],     // [широта, долгота] центра города (пример — заменить)
    ZOOM: 11,
    NAME: 'ЕвроШинСервис',
    ADDRESS: '[Адрес сервиса]',
    HOURS: '[ЧЧ:ММ – ЧЧ:ММ]',
    PHONE_TEXT: '+7 (XXX) XXX-XX-XX',
    PHONE_HREF: 'tel:+7XXXXXXXXXX'
  };

  /* ===== Линейные иконки (stroke 1.5) ===== */
  var ICONS = {
    tire: '<circle cx="12" cy="12" r="9"/><circle cx="12" cy="12" r="3.5"/><path d="M12 3v5.5M12 15.5V21M3 12h5.5M15.5 12H21"/>',
    wrench: '<path d="M14.7 6.3a1 1 0 0 0 0 1.4l1.6 1.6a1 1 0 0 0 1.4 0l3.77-3.77a6 6 0 0 1-7.94 7.94l-6.91 6.91a2.12 2.12 0 0 1-3-3l6.91-6.91a6 6 0 0 1 7.94-7.94l-3.76 3.76z"/>',
    package: '<path d="M11 21.73a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73z"/><path d="M12 22V12"/><path d="m3.3 7 8.7 5 8.7-5"/><path d="m7.5 4.27 9 5.15"/>',
    phone: '<path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z"/>',
    clock: '<circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/>',
    pin: '<path d="M20 10c0 6-8 12-8 12S4 16 4 10a8 8 0 0 1 16 0z"/><circle cx="12" cy="10" r="3"/>',
    shield: '<path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/><polyline points="9 12 11 14 15 10"/>',
    check: '<polyline points="20 6 9 17 4 12"/>',
    search: '<circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/>',
    file: '<path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/><line x1="16" y1="13" x2="8" y2="13"/><line x1="16" y1="17" x2="8" y2="17"/>',
    car: '<path d="M19 17h2c.6 0 1-.4 1-1v-3c0-.9-.7-1.7-1.5-1.9C18.7 10.6 16 10 16 10s-1.3-1.4-2.2-2.3c-.5-.4-1.1-.7-1.8-.7H5c-.6 0-1.1.4-1.4.9l-1.4 2.9A3.7 3.7 0 0 0 2 12v4c0 .6.4 1 1 1h2"/><circle cx="7" cy="17" r="2"/><path d="M9 17h6"/><circle cx="17" cy="17" r="2"/>',
    gauge: '<path d="m12 14 4-4"/><path d="M3.34 19a10 10 0 1 1 17.32 0"/>',
    activity: '<polyline points="22 12 18 12 15 21 9 3 6 12 2 12"/>',
    drop: '<path d="M12 2.69l5.66 5.66a8 8 0 1 1-11.31 0z"/>',
    sliders: '<line x1="4" y1="21" x2="4" y2="14"/><line x1="4" y1="10" x2="4" y2="3"/><line x1="12" y1="21" x2="12" y2="12"/><line x1="12" y1="8" x2="12" y2="3"/><line x1="20" y1="21" x2="20" y2="16"/><line x1="20" y1="12" x2="20" y2="3"/><line x1="1" y1="14" x2="7" y2="14"/><line x1="9" y1="8" x2="15" y2="8"/><line x1="17" y1="16" x2="23" y2="16"/>',
    engine: '<path d="M3 10v6"/><path d="M6 8h9l2 2h2v7H6z"/><path d="M21 12v3"/><path d="M10 8V5.5h4V8"/>',
    zap: '<polygon points="13 2 3 14 12 14 11 22 21 10 12 10 13 2"/>',
    arrow: '<line x1="5" y1="12" x2="19" y2="12"/><polyline points="12 5 19 12 12 19"/>',
    chevron: '<polyline points="6 9 12 15 18 9"/>',
    warehouse: '<path d="M3 21V9l9-6 9 6v12"/><path d="M8 21v-7h8v7"/><path d="M8 17.5h8"/>',
    calendar: '<rect x="3" y="4" width="18" height="18" rx="2"/><line x1="16" y1="2" x2="16" y2="6"/><line x1="8" y1="2" x2="8" y2="6"/><line x1="3" y1="10" x2="21" y2="10"/>',
    refresh: '<path d="M21 12a9 9 0 1 1-3-6.7L21 8"/><path d="M21 3v5h-5"/>',
    quote: '<path d="M16 3a2 2 0 0 0-2 2v6a2 2 0 0 0 2 2 1 1 0 0 1 1 1v1a2 2 0 0 1-2 2 1 1 0 0 0-1 1v2a1 1 0 0 0 1 1 6 6 0 0 0 6-6V5a2 2 0 0 0-2-2z"/><path d="M5 3a2 2 0 0 0-2 2v6a2 2 0 0 0 2 2 1 1 0 0 1 1 1v1a2 2 0 0 1-2 2 1 1 0 0 0-1 1v2a1 1 0 0 0 1 1 6 6 0 0 0 6-6V5a2 2 0 0 0-2-2z"/>',
    globe: '<circle cx="12" cy="12" r="10"/><path d="M2 12h20"/><path d="M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z"/>',
    truck: '<path d="M1 3h15v13H1z"/><path d="M16 8h4l3 3v5h-7z"/><circle cx="5.5" cy="18.5" r="2.5"/><circle cx="18.5" cy="18.5" r="2.5"/>',
    layers: '<polygon points="12 2 2 7 12 12 22 7 12 2"/><polyline points="2 17 12 22 22 17"/><polyline points="2 12 12 17 22 12"/>',
    camera: '<path d="M23 19a2 2 0 0 1-2 2H3a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h4l2-3h6l2 3h4a2 2 0 0 1 2 2z"/><circle cx="12" cy="13" r="4"/>',
    route: '<circle cx="6" cy="19" r="3"/><path d="M9 19h8.5a3.5 3.5 0 0 0 0-7h-11a3.5 3.5 0 0 1 0-7H15"/><circle cx="18" cy="5" r="3"/>'
  };

  function $(s, c) { return (c || document).querySelector(s); }
  function $$(s, c) { return Array.prototype.slice.call((c || document).querySelectorAll(s)); }

  function injectIcons(root) {
    $$('[data-icon]', root).forEach(function (el) {
      var p = ICONS[el.getAttribute('data-icon')];
      if (!p || el.firstChild) return;
      el.innerHTML = '<svg viewBox="0 0 24 24" width="24" height="24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false">' + p + '</svg>';
    });
  }

  /* ===== Мобильная панель «Позвонить / Записаться» ===== */
  var leadSection = $('#lead');
  var headerPhone = $('.header-phone');
  var bar = null;
  if (leadSection) {
    bar = document.createElement('div');
    bar.className = 'mobile-cta';
    bar.innerHTML =
      '<a class="btn btn-secondary" href="' + (headerPhone ? headerPhone.getAttribute('href') : CONFIG.PHONE_HREF) + '"><i data-icon="phone"></i>Позвонить</a>' +
      '<a class="btn btn-primary" href="#lead" data-book>Записаться</a>';
    document.body.appendChild(bar);
  }

  injectIcons(document);

  /* ===== Подсветка текущей страницы ===== */
  var current = (location.pathname.split('/').pop() || 'index.html').toLowerCase();
  $$('.nav a[href]').forEach(function (a) {
    if (a.getAttribute('href').toLowerCase() === current) a.setAttribute('aria-current', 'page');
  });

  /* ===== Бургер-меню ===== */
  var burger = $('.burger');
  var nav = $('#nav');
  function setMenu(open) {
    if (!burger || !nav) return;
    nav.classList.toggle('open', open);
    burger.setAttribute('aria-expanded', String(open));
    burger.setAttribute('aria-label', open ? 'Закрыть меню' : 'Открыть меню');
  }
  if (burger && nav) {
    burger.addEventListener('click', function () { setMenu(burger.getAttribute('aria-expanded') !== 'true'); });
    nav.addEventListener('click', function (e) { if (e.target.closest('a')) setMenu(false); });
    document.addEventListener('keydown', function (e) { if (e.key === 'Escape') setMenu(false); });
    window.addEventListener('resize', function () { if (window.innerWidth >= 1240) setMenu(false); });
  }

  /* ===== Тень у шапки при прокрутке ===== */
  var header = $('.site-header');
  function onScroll() { if (header) header.classList.toggle('scrolled', window.scrollY > 8); }
  window.addEventListener('scroll', onScroll, { passive: true });
  onScroll();

  /* ===== Год в подвале ===== */
  $$('[data-year]').forEach(function (el) { el.textContent = new Date().getFullYear(); });

  /* ===== Плавное появление блоков ===== */
  var revealEls = $$('.reveal');
  function done(el) { setTimeout(function () { el.classList.remove('reveal', 'in'); }, 1000); }
  if ('IntersectionObserver' in window) {
    var io = new IntersectionObserver(function (entries) {
      entries.forEach(function (en) {
        if (en.isIntersecting) { en.target.classList.add('in'); io.unobserve(en.target); done(en.target); }
      });
    }, { rootMargin: '0px 0px -8% 0px', threshold: 0.08 });
    revealEls.forEach(function (el) { io.observe(el); });
  } else {
    revealEls.forEach(function (el) { el.classList.add('in'); });
  }

  /* ===== Аккордеон ===== */
  $$('.acc-btn').forEach(function (btn) {
    btn.addEventListener('click', function () {
      var open = btn.getAttribute('aria-expanded') === 'true';
      $$('.acc-btn').forEach(function (b) { b.setAttribute('aria-expanded', 'false'); });
      btn.setAttribute('aria-expanded', String(!open));
    });
  });

  /* ===== Форма заявки ===== */
  var form = $('#lead-form');
  var defaultService = document.body.getAttribute('data-service') || '';

  function setService(v) {
    if (form && form.elements.service) form.elements.service.value = v || '';
  }

  if (form) {
    var el = form.elements;
    var success = $('#form-success');
    setService(defaultService);

    $$('[data-book]').forEach(function (b) {
      b.addEventListener('click', function () {
        var s = b.getAttribute('data-service') || defaultService;
        if (s) setService(s);
      });
    });

    // Маска телефона: +7 (___) ___-__-__
    function phoneDigits(v) {
      var d = v.replace(/\D/g, '');
      if (d.charAt(0) === '7' || d.charAt(0) === '8') d = d.slice(1);
      return d.slice(0, 10);
    }
    function formatPhone(v) {
      var d = phoneDigits(v);
      var o = '+7 (' + d.slice(0, 3);
      if (d.length > 3) o += ') ' + d.slice(3, 6);
      if (d.length > 6) o += '-' + d.slice(6, 8);
      if (d.length > 8) o += '-' + d.slice(8, 10);
      return o;
    }
    el.phone.addEventListener('focus', function () { if (!el.phone.value) el.phone.value = '+7 ('; });
    el.phone.addEventListener('input', function () {
      el.phone.value = formatPhone(el.phone.value);
      setError(el.phone, '');
    });
    el.phone.addEventListener('blur', function () { if (phoneDigits(el.phone.value).length === 0) el.phone.value = ''; });

    function setError(input, msg) {
      var field = input.closest('.field');
      var err = field.querySelector('.err');
      field.classList.toggle('invalid', !!msg);
      if (msg) input.setAttribute('aria-invalid', 'true'); else input.removeAttribute('aria-invalid');
      if (err) err.textContent = msg;
    }

    ['name', 'year', 'consent'].forEach(function (n) {
      el[n].addEventListener('input', function () { setError(el[n], ''); });
      el[n].addEventListener('change', function () { setError(el[n], ''); });
    });

    function validate() {
      var bad = [];
      var maxYear = new Date().getFullYear() + 1;
      if (el.name.value.trim().length < 2) { setError(el.name, 'Укажите ваше имя'); bad.push(el.name); } else setError(el.name, '');
      if (phoneDigits(el.phone.value).length !== 10) { setError(el.phone, 'Введите номер полностью: +7 (XXX) XXX-XX-XX'); bad.push(el.phone); } else setError(el.phone, '');
      var y = el.year.value.trim();
      if (y && (!/^\d{4}$/.test(y) || +y < 1950 || +y > maxYear)) { setError(el.year, 'Укажите год от 1950 до ' + maxYear); bad.push(el.year); } else setError(el.year, '');
      if (!el.consent.checked) { setError(el.consent, 'Нужно согласие на обработку персональных данных'); bad.push(el.consent); } else setError(el.consent, '');
      return bad;
    }

    form.addEventListener('submit', function (e) {
      e.preventDefault();
      if (success) success.hidden = true;
      var bad = validate();
      if (bad.length) { bad[0].focus(); return; }
      var data = {
        name: el.name.value.trim(),
        phone: el.phone.value,
        car: el.car.value.trim(),
        year: el.year.value.trim(),
        service: el.service.value,
        comment: el.comment.value.trim(),
        consent: el.consent.checked,
        page: location.pathname.split('/').pop() || 'index.html',
        sentAt: new Date().toISOString()
      };
      // Заглушка отправки: здесь будет запрос на сервер / в CRM
      console.log('Заявка (заглушка отправки):', data);
      form.reset();
      setService(defaultService);
      $$('.field', form).forEach(function (f) { f.classList.remove('invalid'); });
      if (success) { success.hidden = false; success.scrollIntoView({ behavior: 'smooth', block: 'nearest' }); }
    });
  }

  /* ===== Мобильная панель: прячем рядом с формой ===== */
  if (bar && 'IntersectionObserver' in window) {
    new IntersectionObserver(function (entries) {
      bar.classList.toggle('is-hidden', entries[0].isIntersecting);
    }, { threshold: 0.15 }).observe(leadSection);
  }

  /* ===== Маршрут (навигатор) ===== */
  function openRoute() {
    var lat = CONFIG.CITY_CENTER[0], lon = CONFIG.CITY_CENTER[1];
    var web = 'https://yandex.ru/maps/?rtext=~' + lat + ',' + lon + '&rtt=auto';
    if (/Android|iPhone|iPad|iPod/i.test(navigator.userAgent)) {
      var t = setTimeout(function () { window.open(web, '_blank', 'noopener'); }, 900);
      document.addEventListener('visibilitychange', function () { if (document.hidden) clearTimeout(t); }, { once: true });
      window.location.href = 'yandexnavi://build_route_on_map?lat_to=' + lat + '&lon_to=' + lon;
    } else {
      window.open(web, '_blank', 'noopener');
    }
  }
  document.addEventListener('click', function (e) {
    if (e.target.closest('[data-route]')) { e.preventDefault(); openRoute(); }
  });

  /* ===== Яндекс.Карта ===== */
  var mapEl = $('#map');
  if (mapEl && CONFIG.YANDEX_API_KEY) {
    var s = document.createElement('script');
    s.src = 'https://api-maps.yandex.ru/2.1/?apikey=' + encodeURIComponent(CONFIG.YANDEX_API_KEY) + '&lang=ru_RU';
    s.onload = function () {
      if (!window.ymaps) return;
      window.ymaps.ready(function () {
        var stub = $('#map-stub');
        if (stub) stub.remove();
        var map = new window.ymaps.Map(mapEl, {
          center: CONFIG.CITY_CENTER, zoom: CONFIG.ZOOM, controls: ['zoomControl', 'geolocationControl']
        });
        map.behaviors.disable('scrollZoom');
        var body =
          '<div class="balloon"><strong>' + CONFIG.NAME + '</strong>' +
          '<p>' + CONFIG.ADDRESS + '</p>' +
          '<p>Часы работы: ' + CONFIG.HOURS + '</p>' +
          '<p>Телефон: <a href="' + CONFIG.PHONE_HREF + '">' + CONFIG.PHONE_TEXT + '</a></p>' +
          '<button type="button" class="btn btn-primary btn-sm" data-route>Проложить маршрут</button></div>';
        var pm = new window.ymaps.Placemark(CONFIG.CITY_CENTER,
          { hintContent: CONFIG.NAME, balloonContent: body },
          { preset: 'islands#orangeDotIcon', hideIconOnBalloonOpen: false });
        map.geoObjects.add(pm);
      });
    };
    document.head.appendChild(s);
  }
})();
